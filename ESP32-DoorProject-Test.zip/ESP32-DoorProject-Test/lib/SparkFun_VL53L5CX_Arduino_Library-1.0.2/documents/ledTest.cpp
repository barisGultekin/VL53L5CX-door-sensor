#include <WiFi.h>
#include <WiFiClient.h>
#include <WebServer.h>
#include <ESPmDNS.h>
#include <Update.h>

#include <Wire.h>

#include <SparkFun_VL53L5CX_Library.h>  //http://librarymanager/All#SparkFun_VL53L5CX

SparkFun_VL53L5CX myImager;
VL53L5CX_ResultsData measurementData;  // Result data class structure, 1356 byes of RAM

int imageResolution = 0;  //Used to pretty print output
int imageWidth = 0;       //Used to pretty print output

#define REDLED 23
#define GREENLED 22

void setup(void) {
  Serial.begin(9600);

  Wire.begin();           //This resets to 100kHz I2C
  Wire.setClock(400000);  //Sensor has max I2C freq of 400kHz

  Serial.println("Initializing sensor board. This can take up to 10s. Please wait.");
  if (myImager.begin() == false) {
    Serial.println(F("Sensor not found - check your wiring. Freezing"));
    while (1)
      ;
  }

  myImager.setResolution(4 * 4);  //Enable all 64 pads

  imageResolution = myImager.getResolution();  //Query sensor for current resolution - either 4x4 or 8x8
  imageWidth = sqrt(imageResolution);          //Calculate printing width

  Serial.print("Image Width is set to ");
  Serial.println(imageWidth);
  Serial.print("Image Resolution is set to ");
  Serial.println(imageResolution);

  //Using 4x4, min frequency is 1Hz and max is 60Hz
  //Using 8x8, min frequency is 1Hz and max is 15Hz
  bool response = myImager.setRangingFrequency(5);
  if (response == true)
  {
    int frequency = myImager.getRangingFrequency();
    if (frequency > 0)
    {
      Serial.print("Ranging frequency set to ");
      Serial.print(frequency);
      Serial.println(" Hz.");
    }
    else
      Serial.println(F("Error recovering ranging frequency."));
  }
  else
  {
    Serial.println(F("Cannot set ranging frequency requested. Freezing..."));
    while (1) ;
  }
  myImager.startRanging();
  pinMode(REDLED, OUTPUT);
  pinMode(GREENLED, OUTPUT);
}

void loop(void) {
  delay(1);

  int sensorData[imageWidth][imageWidth];

  if (myImager.isDataReady() == true)
  {
    if (myImager.getRangingData(&measurementData)) //Read distance data into array
    {
      Serial.println("Mesaurement Data");
      for (int j = 0 ; j <= imageWidth * (imageWidth - 1) ; j += imageWidth)
      {
        for (int i = imageWidth - 1 ; i >= 0 ; i--)
        {
          Serial.print("\t");
          Serial.print(measurementData.distance_mm[i + j]);
          // sensorData[j][i] = measurementData.distance_mm[i + j];
          delay(5);
        }
        delay(5);
        Serial.println();
      }
      Serial.println();
    }
  }

  delay(5);

  // sensorData[0][0]
  // measurementData.distance_mm[0]

  if (measurementData.distance_mm[0] <= 100){
    //Serial.println("TOP");// Top 
    digitalWrite(REDLED, LOW);
  } else {
    digitalWrite(REDLED, HIGH);
  }
}

