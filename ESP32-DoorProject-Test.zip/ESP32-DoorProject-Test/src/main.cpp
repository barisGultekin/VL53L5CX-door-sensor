#include <Arduino.h>

// ToF Sensor Libs
#include <Wire.h>
#include <SparkFun_VL53L5CX_Library.h>

// OTA Update Libs
#include <WiFi.h>
#include <AsyncTCP.h>
#include <ESPAsyncWebServer.h>
#include <AsyncElegantOTA.h>

SparkFun_VL53L5CX myImager;
VL53L5CX_ResultsData measurementData;

#define REDLED 23
#define RELAY 32
#define BUTTON 0

int imageResolution = 0;
int imageWidth = 0;

const char* ssid = "hotspotTester";
const char* password = "12345678";

AsyncWebServer server(80);

void initToF();
void printMatrix();
void runRelay(int pulseLength);
void initServer();

void setup(void)
{
  Serial.begin(115200);

  pinMode(BUTTON, INPUT);
  pinMode(REDLED, OUTPUT);
  pinMode(RELAY, OUTPUT);

  digitalWrite(REDLED, LOW);
  digitalWrite(RELAY, LOW);

  // initServer();

  Wire.begin();
  Wire.setClock(400000);
  initToF();

  Serial.println("ESP32 : DOOR PROJECT\n------------------\n");
}

void loop()
{
  digitalWrite(REDLED, !digitalRead(REDLED));
  printMatrix();
  if ( (measurementData.distance_mm[2]/10 < 60) &&  (measurementData.distance_mm[3]/10 < 60))
    runRelay(500);
  delay(1000);
}

void initToF()
{
  Serial.println("Initializing sensor board. This can take up to 10s. Please wait.");
  while (1)
  {
    if (myImager.begin() == false)
    {
      Serial.println(F("Sensor not found. Trying again."));
      delay(500);
    }
    else
    {
      Serial.println("Succesfully detected the sensor.");
      break;
    }
    Serial.println();
    delay(500);
  }

  myImager.setResolution(4 * 4);
  imageResolution = myImager.getResolution();
  imageWidth = sqrt(imageResolution);

  bool response = myImager.setRangingFrequency(2);

  if (response == true)
  {
    int frequency = myImager.getRangingFrequency();
    if (frequency > 0)
    {
      Serial.print("Ranging frequency set to ");
      Serial.print(frequency);
      Serial.println(" Hz.");
    }
    else
      Serial.println(F("Error recovering ranging frequency."));
  }
  else
  {
    Serial.println(F("Cannot set ranging frequency requested. Freezing..."));
    while (1)
      ;
  }
  myImager.startRanging();
}

void printMatrix()
{
  if (myImager.isDataReady() == true)
  {
    if (myImager.getRangingData(&measurementData))
    {
      Serial.println("Mesaurement Data");
      for (int j = 0; j <= imageWidth * (imageWidth - 1); j += imageWidth)
      {
        for (int i = imageWidth - 1; i >= 0; i--)
        {
          Serial.print("\t");
          Serial.print(measurementData.distance_mm[i + j] / 10);
          delay(5);
        }
        delay(5);
        Serial.println();
      }
      Serial.println();
    }
  }
}

void runRelay(int pulseLength)
{
  digitalWrite(RELAY, HIGH);
  Serial.println("RELAY: HIGH");
  delay(pulseLength);
  digitalWrite(RELAY, LOW);
  Serial.println("RELAY: LOW");
}

void initServer()
{
  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid, password);
  Serial.print("Connecting to WiFi ..");
  while (WiFi.status() != WL_CONNECTED) {
    Serial.print('.');
    delay(500);
  }
  Serial.println(WiFi.localIP());

  server.on("/", HTTP_GET, [](AsyncWebServerRequest *request) {
    request->send(200, "text/plain", "DVLX | ISIK ELEKTRONIK");
  });

  AsyncElegantOTA.begin(&server);
  server.begin();
  Serial.println("HTTP server started");
}